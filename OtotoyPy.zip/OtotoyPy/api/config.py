cfg={
     "credentials": {
        "cookie": "Apache=e60839f2.5b10862027c13; _ga=GA1.2.66648551.1602024458; default_format=wav; udidbv=anon_48ccb468defd3fff95e9a3223ed9b11a1d8c97402f808d77abe1ea37a45e7aaf; f03df53ac8d297e9c9c5b3b9ffceaffc=2a938087d5e597bdba7891da66dcb232; app_token=c8cf29d0f54d3039cee45dd3f55b69f4"
     },
     "directories": {
         "log_directory": "logs",
         "downloads": "/content/drive/Shareddrives/Music Mex",
         "artist_folders": True
        },
     "files": {
        "audio_quality": "wav",
        "fallback_audio_quality": "flac",
        "cover_name": "cover.jpg"
        },
     }
