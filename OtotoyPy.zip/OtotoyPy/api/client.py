# Standard
import requests

# OtotoyPy
import api.config as cfg

### NOTES:
# Public api
# All information required can be obtained with a simple GET request
# Could implement auth perhaps for returning a users purchased tracks

class Client:
    def __init__(self):
        self.session = requests.Session()

    def get_meta(self, type_one, type_two, id):
        try:
            r = self.session.get("https://api.ototoy.jp/app/list/{0}/{1}/{2}".format(type_one, type_two, id))
        except:
            print("Failed to grab metadata")
        return r.json()
